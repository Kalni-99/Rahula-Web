$(document).ready(function () {
    $('#subminbtn').click(function (e) {
        e.preventDefault();

        alert("Successful Submit Your Form");
    });
});